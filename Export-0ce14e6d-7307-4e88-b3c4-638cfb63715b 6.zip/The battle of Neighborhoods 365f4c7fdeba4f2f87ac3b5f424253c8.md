# The battle of Neighborhoods

Created: July 8, 2021 10:31 AM
Created By: Laly lorena cruz
Last Edited By: Laly lorena cruz
Last Edited Time: July 8, 2021 11:56 AM
Status: In Review 👀
Type: Project Kickoff 🚀

**Notion Tip:** Create a new page and select `Project Kickoff` from the list of template options to automatically generate the format below. [Learn more about database templates](https://www.notion.so/Database-templates-454ed5ab5bd24226b58d176697bd7e10).

# Overview

This report has been prepared as a part of the **IBM APPLIED DATA SCIENCE FINAL SUBMISSION CAPSTONE PROJECT**

# Background

Toronto is divided in areas including: East York, Etobicoke, Forest Hill, Mimico, North York, Parkdale, Scarborough, Swansea, Weston and York. Throughout the city there exist hundreds of small neighbourhoods and some larger neighbourhoods covering a few square kilometres.

Having such vast population and big geographical area, there also exists big competition between businesses. Therefore it became very challenging for stake holder or new business to decide which area they should start their business to get higher revenue with lowest possible competition.

# Introduction

In this project we will explore  Scarborough‘s data in the city of Toronto.

Base on the data we will find which location is best suited in the neighborhood to open a new location and expand the business.

# Business Problem

- GRADE A GRILL AND CAFE is a famous eatery/restaurant in North York, Toronto. The owners wants to expand their business, opening 2 new locations in Scarborough. Therefore, the Goal is to find the central points of the 3 highest density eatery areas and take the best decision.

# Methodology

To solve the problem I am going to use “K-Means Clustering Algorithm ". K-means clustering is a type of unsupervised learning, which is used when you have unlabeled data (i.e., data without defined categories or groups). The goal of this algorithm is to find groups in the data, with the numberImplement 

# Data description

- We will be using 2 dta sources:

Link: [https://en.wikipedia.org/wiki/List_of_postal_codes_of_Canada:_M](https://en.wikipedia.org/wiki/List_of_postal_codes_of_Canada:_M)"

Using foursquare data to get information about eateries/restaurants in Toronto, especifically  from Scarborough.

### Non-Requirements

- @mentions in comments
- Nested comments